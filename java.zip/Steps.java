/** 
* Steps.java

* 
* Copyright (c) University of Sheffield, 2021
* 
* @version 1.3 11/01/2021
* 
* @author Maria-Cruz Villa-Uriol
* @author Ben Clegg
* student: Albertina Ripanu 
* date:2/26/2021
*/

package uk.ac.sheffield.com1003.problemsheet1;

public class Steps {
	
	// Instance variables
	private int value;
	
	// Constructor
	public Steps(int value) { 
		this.value = value;
	}
	
	
	public int getValue() {
	    return value;
	}
	public void setValue(int newValue) {
		value = newValue;
	}	

	public String toString() {
		return "You did " + value + " steps";
	}
	
}
