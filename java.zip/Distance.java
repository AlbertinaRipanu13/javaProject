/** 
* Distance.java
* 
* Copyright (c) University of Sheffield, 2021
* 
* @version 1.3 11/01/2021
* 
* @author Maria-Cruz Villa-Uriol
* @author Ben Clegg
* student: Albertina Ripanu 
* date:2/26/2021
*/

package uk.ac.sheffield.com1003.problemsheet1;

public class Distance {

	// Enum of distance units
	public enum DistanceUnit {
		KILOMETRES, MILES
	}

	// Constants
	private static final double KMS_PER_MILE = 1.609;
	private static final double MILES_PER_KM = 0.621;

	// Instance variables
	private double value;
	private DistanceUnit distanceUnit;

	// Constructors
	public Distance(double value) {
		this.value = value;
		// Default unit is km
		this.distanceUnit = DistanceUnit.KILOMETRES;
	}

	public Distance(double value, DistanceUnit distanceUnit) {
		this.value = value;
		this.distanceUnit = distanceUnit;
	}

	public double getValue() {
		return value;
	}
/**
	 * The method checks if is a difference between the unit wanted and the actual unit. If it is different
	 * than the program gives to the variable ,newValue, the new value converted into the unit wanted by
	 * by using the methods convertToMiles and convertToKilometres
	 * @param unit
	 * @return the value of variable "value" converted received by newValue
*/
	public double getValue(DistanceUnit unit) {
		//I create a new variable, newValue, which will receive
		//the variable's "value" value
		double newValue = this.value;
		
		//Checks if the unit that I want to convert into(unit), is different 
		//than the initial unit(distanceUnit)
		if (unit != this.distanceUnit)
			//the variable newValue receives the converted value into the
			//oposite unit.
			if (unit == DistanceUnit.KILOMETRES)
				newValue = convertToKilometres(this.value);
			else
				newValue = convertToMiles(this.value);
      
		return newValue;
	}

	public void setValue(double newValue) {
		value = newValue;
	}

	public DistanceUnit getDistanceUnit() {
		return distanceUnit;
	}
/**
 * The method changes the variable value and the distanceUnit's unit, by checking if 
 * the unit wanted is different than the initial one. If not, the variables stay unchanged.
 * @param newDistanceUnit
 */
	public void changeDistanceUnit(DistanceUnit newDistanceUnit) {
		//Checks if the unit that I want to convert into(newDistanceUnit), is different 
		//than the initial unit(distanceUnit).
		if (newDistanceUnit != this.distanceUnit)
			//Converts into the unit wanted by changing the variable's (value) value
			//and I change the unit of distanceUnit in the new unit.
			if (newDistanceUnit == DistanceUnit.MILES) 
			    {
				this.value = convertToMiles(this.value);
				this.distanceUnit = newDistanceUnit;
				} 
			else 
			    {
				this.value = convertToKilometres(this.value);
				this.distanceUnit = newDistanceUnit;
			    }

	}
/**
 * The method converts kilometers into miles by using the constant MILES_PER_KM and 
 * multiplying it with the number of kilometers.
 * @param kilometres
 * @return the conversion into miles of the method's parameter
 */
	public static double convertToMiles(double kilometres) {
		return MILES_PER_KM * kilometres;
	}
	
/**
 * The method converts kilometers into kilometers by using the constant KILOMETRES_PER_KM and 
 * multiplying it with the number of miles.
 * @param miles
 * @return the conversion into kilometers of the value of method's parameter
 */
	public static double convertToKilometres(double miles) {
		return KMS_PER_MILE * miles;
	}

	public String toString() {
		return "You walked " + getValue() + " " + getDistanceUnit();
	}

}
