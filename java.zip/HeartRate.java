/** 
* HeartRate.java
* 
* Copyright (c) University of Sheffield, 2021
* 
* @version 1.3 11/01/2021
* 
* @author Maria-Cruz Villa-Uriol
* @author Ben Clegg
* student: Albertina Ripanu 
* date:2/26/2021
*/
package uk.ac.sheffield.com1003.problemsheet1;

public class HeartRate {
	
	// Instance variables
	private double value;
	
	// Constructor
	public HeartRate(double value) { 
		this.value = value;
	}
	
	
	public double getValue() {
		return value;
	}
	
	public void setValue(double newValue) {
		value = newValue;
	}	

	public String toString() {
		return "Your heart rate is " + value;
	}
	
}
