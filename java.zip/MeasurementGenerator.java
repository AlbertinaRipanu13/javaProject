/** 
* MeasurementGenerator.java
* 
* Copyright (c) University of Sheffield, 2021
* 
* @version 1.3 11/01/2021
* 
* @author Maria-Cruz Villa-Uriol
* @author Ben Clegg
* 
* student:Albertina Ripanu 
* date:2/26/2021
*/
//
package uk.ac.sheffield.com1003.problemsheet1;

import uk.ac.sheffield.com1003.problemsheet1.Distance.DistanceUnit;

public class MeasurementGenerator {

	public static void main(String[] args) {
        //Instantiate 2 objects of type Steps
		Steps steps1 = new Steps(3567);
		Steps steps2 = new Steps(8290);

		//Instantiate 2 objects oh type HeartRate
		HeartRate rate1 = new HeartRate(67);
		HeartRate rate2 = new HeartRate(80);
		
		//Instantiate 3 objects of type distance1
		Distance distance1 = new Distance(17, DistanceUnit.MILES);
		Distance distance2 = new Distance(19.1);
		Distance distance3 = new Distance(10, DistanceUnit.KILOMETRES);

		//Dispays the two Steps objects, using toString method
		System.out.println(steps1);
		System.out.println(steps2);

		//Dispays the two HeartRate objects, using toString method
		System.out.println(rate1);
		System.out.println(rate2);

		//Displays the three Distance objects, using toString method
		System.out.println();
		System.out.println(distance1);
		System.out.println(distance2);
		System.out.println(distance3);

		//using the method changeDistanceUnit, changes the intial unit 
		//with the other one
		distance1.changeDistanceUnit(DistanceUnit.KILOMETRES);
		distance2.changeDistanceUnit(DistanceUnit.MILES);
		distance3.changeDistanceUnit(DistanceUnit.MILES);
		
		//Displays again the Distance objects, but t=with the unit changed
		//and the value 
		System.out.println();
		System.out.println(distance1);
		System.out.println(distance2);
		System.out.println(distance3);

	}

}
